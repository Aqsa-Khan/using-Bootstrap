#Code modified from http://pastebin.com/TVhwsXbf/
    #This code is so much easier to understand  because instead of functions it uses if loops so we modified it and made it more clear for us
#city scroller.py
#aqsa khan
#july 25,2016
import pygame
import sys
import random
from pygame.locals import *
from PIL import Image
 
# set up pygame
pygame.init()
mainClock = pygame.time.Clock()
 
# set up window
WINDOWWIDTH = 400
WINDOWHEIGHT = 400
windowSurface = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT), 0, 32)
pygame.display.set_caption('City Scroller')
 
# set up the colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
DARK = (38, 16, 30)
MEDIUM = (74, 34, 58)
BRIGHT = (112, 52, 88)
SKY = (0,0,102)
BLUE = (0, 0, 255)
 
 
class Scroller():
    def __init__(self, speed, color, heightMax):
        # set up the building parameters
        self.buildingHeightMax = heightMax
        self.buildingHeightMin = 100
        self.buildingWidthMax = 125
        self.buildingWidthMin = 75
        self.buildings = [] # three buildings lists, one for each parallax layer
        self.layerspeed = speed
        self.buildTime = True
        self.buildCountdown = 10
        self.color = color
 
    def update(self):
        # Check if it's time to build
        if self.buildTime == False:
            self.buildCountdown -= 1
            if self.buildCountdown <= 0:
                self.buildTime = True
                self.buildCountdown = random.randint(3, self.layerspeed)
 
        # create front layer building if it's time
        if self.buildTime:
            # generate random width and height of building, calculate bottom based on height
            buildingHeight = random.randint(self.buildingHeightMin, self.buildingHeightMax)
            buildingWidth = random.randint(self.buildingWidthMin, self.buildingWidthMax)
            buildingTop = WINDOWHEIGHT - buildingHeight
            # This generates the building object from the above parameters
            building = pygame.Rect(WINDOWWIDTH, buildingTop, buildingWidth, WINDOWHEIGHT)
            self.buildTime = False
            self.buildCountdown = random.randint(3, self.layerspeed * 5)
            # add building to buildings list
            self.buildings.append(building)
 
        # move all buildings on Front layer at set speed
        for building in self.buildings:
            if building.right < 0:
                self.buildings.remove(building)
            else:
                building.left -= self.layerspeed
 
 
        # draw the Front buildings
        for i in range(len(self.buildings)):
            pygame.draw.rect(windowSurface, self.color, self.buildings[i])
 
 
 
def main():
 
  
    # Set up scrolling background layers
    # Works best when front row is darker than middle
    # and back row is lightest
    city_back_row = Scroller(3, BRIGHT, 350)
    city_middle_row = Scroller(5, MEDIUM, 300)
    city_front_row = Scroller(7, DARK, 250)
 
    # run the main loop, generate random skyline
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
 
 
        # draw the black background onto the surface
        windowSurface.fill(SKY)
 
        # Create 3 parallax scrollers for background
        city_back_row.update()
        city_middle_row.update()
        city_front_row.update()

 
        # draw the window onto the screen
        pygame.display.update()
        mainClock.tick(40)
 
 
main()
