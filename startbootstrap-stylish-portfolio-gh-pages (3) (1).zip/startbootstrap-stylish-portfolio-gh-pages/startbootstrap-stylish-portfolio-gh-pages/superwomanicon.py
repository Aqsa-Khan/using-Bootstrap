#import
from PIL import Image

doge = Image.open("superwoman slays.jpg")
doge.show()
width = 400
height = 400
darkBlue = (0, 51, 76)
red = (217, 26, 33)
lightBlue = (112, 150, 158)
yellow = (252, 227, 166)
#to get rgb value...use getdata()-> make that into a list
data = list(doge.getdata())

#how to make new image
new_image = Image.new("RGB",(width,height))
#save new image before opening it
new_image.save("output.jpg", "jpeg")
#new_image.show()
colorVal = list(doge.getdata())
#store rgb values..make a list-> populate with rgb-> putdata()
newlist = []
#go through data list
for i in range(0, len(colorVal)):
   intensity = colorVal[i][0]+colorVal[i][1]+colorVal[i][1]

   if intensity<182:
       newlist.append(darkBlue)
   elif intensity >= 182 and intensity < 364:
       newlist.append(red)
   elif intensity >= 364 and intensity < 546:
       newlist.append(lightBlue)
   elif intensity >= 546:
       newlist.append(yellow)
  
# NEXT TIME I WILL READ THE INSTRUCTIONS     

new_image.putdata(newlist)
new_image.save("output.jpg","jpeg")
new_image.show()
